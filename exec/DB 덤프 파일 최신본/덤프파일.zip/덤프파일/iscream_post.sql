-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: iscream
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `view_count` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `like_count` int DEFAULT '0',
  PRIMARY KEY (`post_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (19,7,'오늘 처음 방문했어요~!','많은 도움 주시면 감사하겠습니다',6,'2025-02-20 19:29:49','2025-02-21 05:30:00',1),(20,7,'아이가 많이 예민해서 고민이에요','아이가 점점 화가 많아지고 예민해서 고민이에요 어떻게 해야 아이가 바른 방향으로 성장 할 수 있을까요?',5,'2025-02-20 19:32:14','2025-02-21 05:30:00',1),(21,18,'아이가 학교에서 적응을 못 하는거 같아요','상담을 받아야 할까요?',14,'2025-02-20 19:32:43','2025-02-21 05:30:00',2),(27,7,'안녕하세요','아이 양육 방식 고민 들어주실분!',3,'2025-02-20 19:42:13','2025-02-21 05:30:00',0),(28,18,'어제 방문한 상담 센터 후기','앱에서 추천해준 센터에 방문해 봤는데 정말 친절하게 상담해주셨어요\n역삼역에 서울 아동 심리상담센터에요!!',12,'2025-02-20 19:51:37','2025-02-21 05:30:00',3),(29,19,'안녕하세요^^','다들 화이팅!!',4,'2025-02-20 21:26:31','2025-02-20 23:04:35',1),(30,2,'아이가 자극에 많이 예민하고 친구사귀는걸 힘들어해요','안녕하세요. \n이번에 아이가 초등학교 입학을 앞두면서 고민이 많아졌습니다. 어릴때부터 자극에 예민해서 밤에도 자주 깨고, 이유식도 아무것도 못먹었던 아이입니다.\n친구관계나 선생님과의 관계에서도 많이 예민하고 힘들어해서 유치원도 많은 고민 끝에 보냈어요. 그래도 중간에 쉴 수 있는 유치원과는 달리 초등학교는 또 다를 텐데... 선생님께 따로 부탁을 드려도 될지 의견을 부탁드려요ㅜㅜ',11,'2025-02-20 21:28:23','2025-02-21 05:30:00',2),(31,20,'무료로 HTP검사를 받는다고요?','와... 학교에서나 교육청에서 겨우 해주던 검사 아닌가요? 그걸 무료로 어디서나 받을 수 있다니..',8,'2025-02-20 22:14:45','2025-02-21 05:30:00',2),(32,1,'안녕하세요','아이 양육 방식 고민 들어주실 분',14,'2025-02-20 22:57:42','2025-02-21 08:00:00',0),(34,26,'안녕하세요 처음 가입했어요^^','만나서 반갑습니다!',6,'2025-02-21 00:07:33','2025-02-21 05:30:00',2),(35,3,'아이가 너무 좋아해요','그냥 재미로 해보라고 했는데 너무 좋아하네요!',1,'2025-02-21 07:58:06','2025-02-21 08:00:00',0);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  8:55:01
