-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: iscream
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `big_five_question`
--

DROP TABLE IF EXISTS `big_five_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `big_five_question` (
  `big_five_question_id` int NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`big_five_question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `big_five_question`
--

LOCK TABLES `big_five_question` WRITE;
/*!40000 ALTER TABLE `big_five_question` DISABLE KEYS */;
INSERT INTO `big_five_question` VALUES (1,'나는 의지가 강해서 내가 하는 일을 중간에 그만두지 않고 끝까지 해낼 수 있어요!','CONSCIENTIOUSNESS'),(2,'나는 어려운 문제도 포기하지 않고 열심히 해결할 수 있어요.','CONSCIENTIOUSNESS'),(3,'나는 많은 것들을 능숙하게 잘 해낼 수 있어요.','CONSCIENTIOUSNESS'),(4,'나는 내 마음 속 기준이 높아서 내가 하는 일을 매우 잘 해야 해요.','CONSCIENTIOUSNESS'),(5,'나는 스트레스를 받으면 어쩔줄 모르겠어요.','AGREEABLENESS'),(6,'나는 스트레스를 받으면 얼어버리거나 어떤 일을 반복적으로 해요.','AGREEABLENESS'),(7,'나는 일이 잘못되거나 스트레스를 받으면 몸이 아프기도 해요.','AGREEABLENESS'),(8,'나는 놀림을 받거나 비판을 받으면 마음이 쉽게 슬퍼져요.','AGREEABLENESS'),(9,'나는 다른 친구들에게 친절하고 배려하며 대해요.','EMOTIONAL_STABILITY'),(10,'나는 생각이 깊고 다른사람들을 배려해요.','EMOTIONAL_STABILITY'),(11,'나는 가까운 사람을 보호해주고 싶어요.','EMOTIONAL_STABILITY'),(12,'우리 반 친구들이랑 다른 어른들은 보통 나를 좋아하는 것 같아요.','EMOTIONAL_STABILITY'),(13,'나는 감정을 있는 그대로 표현할 수 있어요.','EXTRAVERSION'),(14,'나는 생각과 느낌을 잘 표현하지 않아요.','EXTRAVERSION'),(15,'나는 다른 사람들에게 편하게 다가가는게 어려워요.','EXTRAVERSION'),(16,'나는 말이 많은 편이에요.','EXTRAVERSION'),(17,'나는 어떤 물건을 두고 창의적으로 생각하는게 재미있어요.','OPENNESS'),(18,'나는 상상하는 걸 좋아해요.','OPENNESS');
/*!40000 ALTER TABLE `big_five_question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  8:54:53
