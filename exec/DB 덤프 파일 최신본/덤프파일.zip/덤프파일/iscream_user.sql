-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: iscream
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` date DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('ACTIVE','INACTIVE','BANNED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `relation` enum('MOTHER','FATHER','REST') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REST',
  `role` enum('ADMIN','USER') COLLATE utf8mb4_unicode_ci DEFAULT 'USER',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'test','test@naver.com','$2a$10$kILeDQbTrEXEv5SIKxJrmOFuUx9tGXoQQVB2tNjFRbTITBrKbGqA2','2024-01-31','010-1111-2222','2025-02-17 00:41:37','2025-02-18 17:31:56','ACTIVE','test',NULL,'MOTHER','USER'),(2,'김유정','tomato@naver.com','$2a$10$oK0UF3VbWNRBrd7Ck1pg.uvuqAVutu8dZMNwC0vLztZMnxrCNLlmK','2000-01-18','010-2835-9914','2025-02-17 00:43:49','2025-02-20 18:12:55','ACTIVE','김유정','https://a407-20250124.s3.ap-northeast-2.amazonaws.com/images/f6f9959a-d9c9-4db5-a6e9-05567f8194f1_1740042774707.jpg','MOTHER','USER'),(3,'박보성','qkrqhd23@naver.com','$2a$10$AI8oGj2OBU38z.xhZhusV.3WlzmobzJZNzIy07XXJ5EShJyopoGxK','1997-07-16','010-3422-0247','2025-02-17 00:46:29','2025-02-17 13:53:11','ACTIVE','보난','https://a407-20250124.s3.ap-northeast-2.amazonaws.com/images/da59d0a3-3f33-4cdb-8bea-87fc48b06dfe_1739767990958.png','MOTHER','USER'),(4,'testtest','test@example.com','$2a$10$Z1G2a2jKiutZa.rOh5vOMeAlpcR9niV4XGPMzHeLR4b6rf1zABJ7q','2025-02-17','010-0000-0000','2025-02-17 01:24:30','2025-02-17 01:24:30','ACTIVE','testtest',NULL,'FATHER','USER'),(5,'minchae','minchae@naver.com','$2a$10$aUVaQcSl4iGDpYQ8lXLvV.ryZx6KWbLxc.IQZrv.rbZJxNIgpbtM6','2024-01-31','010-2222-2','2025-02-17 11:41:14','2025-02-19 05:52:36','ACTIVE','minchae',NULL,'REST','USER'),(6,'박보셩','boseong@naver.com','$2a$10$cHe7ZuLMFF7E9IklAhuXfevghJpXJWrARioKJRAcwqnWQFy9w2GlK','2000-10-20','010-1234-5678','2025-02-17 12:21:36','2025-02-17 12:21:36','ACTIVE','ㅂㅈㄷㄱ',NULL,'MOTHER','USER'),(7,'서건호','jjkkgh123@naver.com','$2a$10$gI9QbKOovDQCe9nYw.s0Xe0YwQFUOgoR063wtrWJsZ9ZPSa6s3yyW','1997-12-30','010-3311-4128','2025-02-17 17:33:50','2025-02-20 19:31:02','ACTIVE','아빠행복',NULL,'FATHER','USER'),(8,'고성현','cavalier7@naver.com','$2a$10$/UG.3fGgOX6lilV/rOsgZu.G6AU2SC/15QZkyUvY40sTeotIO9Q2C','1976-10-09','010-2010-5910','2025-02-19 00:39:49','2025-02-19 00:39:49','ACTIVE','서4컨',NULL,'FATHER','USER'),(9,'서건호','','$2a$10$AGp0cLKRru5U29GF/PGMUOOQ1zfcB/k7f2Y2fwP4uMzbALhmjH4Tu','1997-12-30','010-3311-4129','2025-02-19 00:57:28','2025-02-19 03:53:48','BANNED','탈퇴한 사용자',NULL,'FATHER','USER'),(10,'test11','test11@naver.com','$2a$10$IiXtJSvhUThkpmn3JaaGYePhFFm42mLWD5O54gOjnX9ukDFQL5g5O','2024-01-31','010-1111-2222','2025-02-19 10:02:49','2025-02-19 10:02:49','ACTIVE','test11',NULL,'REST','USER'),(11,'서건호',NULL,'$2a$10$kmDHo8h6yv1DrWAgg0UbWuBad8OaoL0UJ2DAyQCGGJyNtDr6CmU7.','1997-12-30','010-3311-4128','2025-02-19 03:34:01','2025-02-19 05:27:14','BANNED','탈퇴한 사용자',NULL,'MOTHER','USER'),(12,'testtest',NULL,'$2a$10$YmdMj9kUL5dEUc31ZLhSRuoD90sm6E8H5iN5FRK2z4ckNP/wAv5TC','2024-01-31','010-1111-2222','2025-02-19 12:59:56','2025-02-19 13:00:35','BANNED','탈퇴한 사용자',NULL,'REST','USER'),(13,'이이재재홍홍','jaehong@good.com','$2a$10$L/HvRjMnywV2yANyDQIfyOtfUK4NJ2pZZQWAdLWmnC8MpkOC2H26G','1998-09-15','010-0101-0101','2025-02-19 05:23:25','2025-02-19 05:23:25','ACTIVE','홍',NULL,'FATHER','USER'),(14,'서건호',NULL,'$2a$10$WSkx1J21OMFW4TidhBa3eOrG7kA3176mAonoAirHTeL2myzckofiq','1997-12-30','010-3311-4128','2025-02-19 05:28:11','2025-02-19 05:28:18','BANNED','탈퇴한 사용자',NULL,'FATHER','USER'),(15,'서건호','test23@naver.com','$2a$10$e7dT8h/2EWFCqSufJJ4aXeDtH7EB2ZEpTRvrNhjYSBi3fe7hmOI8G','1997-12-29','010-3311-4128','2025-02-19 05:56:49','2025-02-19 05:56:49','ACTIVE','삶이팍팍',NULL,'FATHER','USER'),(16,'서건호','jjkkgh@naver.com','$2a$10$9b4.9u6V45seRhKLoJ0vGexoylH8pGIRMrSyo8gbdbA4QxtsCf/iq','1997-12-30','010-1123-2321','2025-02-19 22:37:54','2025-02-19 22:37:54','ACTIVE','하지마',NULL,'FATHER','USER'),(17,'히히히히','abc@naver.com','$2a$10$828/l/nbTq/DaWYQtsw5Q.TcVEeSZyCEvktALnrU/pdrw3tXIY4QC','1997-01-10','010-8886-6677','2025-02-19 22:44:48','2025-02-19 22:44:48','ACTIVE','기미이이니미',NULL,'MOTHER','USER'),(18,'박동민임','eyeben@naver.com','$2a$10$z/a8xb38jgHk5lXIl22N1.fQVhiyGBRJpUcFoRe.N/ePghoUYEOqu','1997-04-24','010-8181-3908','2025-02-19 22:51:08','2025-02-19 22:51:08','ACTIVE','eyeben',NULL,'MOTHER','USER'),(19,'강유정','unikang16@gmail.com','$2a$10$ObAjqVdDLP8qzHq3BKrkUOAuECX9ZL.sFc7W8Z0sZNUCgfOe0zoD6','1996-08-13','010-4048-6729','2025-02-20 20:04:16','2025-02-20 21:09:59','ACTIVE','내가김유정',NULL,'MOTHER','USER'),(20,'qkrqhtjd','slsk402@naver.com','$2a$10$EpmVjjVXc1XefB9wzoMvCezxuodVERYbqBLH56OWfYsFH4mcJhKoS','1997-07-16','010-1234-5678','2025-02-20 22:13:27','2025-02-20 22:13:27','ACTIVE','두딸아빠',NULL,'FATHER','USER'),(21,'황다빈','dabin12648@gmail.com','$2a$10$l1NscY1rwoH8wohXrTCpi.U20WV5qMIQ68hbE0MpyAo3bw40wKMd.','2002-01-26','010-8465-8864','2025-02-20 22:35:37','2025-02-20 22:35:37','ACTIVE','다바',NULL,'MOTHER','USER'),(22,'null',NULL,'$2a$10$La7AENOL/qhk3Yr6DJvZgusksCZoIp.zkdRY6/MviP9ffHf1xTn5i','1900-04-09','010-1010-1010','2025-02-20 23:19:26','2025-02-20 23:31:35','BANNED','탈퇴한 사용자',NULL,'MOTHER','USER'),(23,'ga',NULL,'$2a$10$g4Glx.24wpWIQ.P3kSpuy.I7zJ75MAA0.51aHzWXQaQ1rZXU3Nx9K','1995-01-23','010-0101-0101','2025-02-20 23:39:45','2025-02-20 23:41:52','BANNED','탈퇴한 사용자',NULL,'FATHER','USER'),(24,'null',NULL,'$2a$10$RRJEWVYQOpNuGapfQiiP3ulog4XW13YcChEpIFeH.S3gh71lCVH92','1991-12-15','010-1010-1010','2025-02-20 23:40:40','2025-02-20 23:50:42','BANNED','탈퇴한 사용자',NULL,'MOTHER','USER'),(25,'null',NULL,'$2a$10$LVN2616Ehu84hWub7rLgWei8pQnWnWXVFT4jMlQWxxky4.7Y9OjUa','2000-12-12','010-1010-1000','2025-02-20 23:41:35','2025-02-20 23:50:57','BANNED','탈퇴한 사용자',NULL,'FATHER','USER'),(26,'지유정','kimbabo@naver.com','$2a$10$OcWfYpYnB0SceSSJguoqMeJRRyyiCebnZChFzPlJcOpVN3WPZOcvq','2000-01-18','010-1234-5678','2025-02-21 00:00:10','2025-02-21 00:00:10','ACTIVE','지유정데스',NULL,'MOTHER','USER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  8:55:04
