-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: iscream
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `education`
--

DROP TABLE IF EXISTS `education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `education` (
  `education_id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recommend_type` enum('AGREEABLENESS','CONSCIENTIOUSNESS','EMOTIONAL_STABILITY','EXTRAVERSION','OPENNESS') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`education_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education`
--

LOCK TABLES `education` WRITE;
/*!40000 ALTER TABLE `education` DISABLE KEYS */;
INSERT INTO `education` VALUES (2,'겁 많은 아이는 어떻게 해야 창의성에 유리할까? 자기주장 강한 아이, 창의성도 더 높을까? 자유 놀이는 창의성 증진에 왜 중요할까? 한글 교육은 정말 창의성에 나쁠까?','OPENNESS','https://img.youtube.com/vi/MFphfVq5HoY/0.jpg','알아만 둬도 창의적인 아이로 키우는 데 도움되는 지식들','https://www.youtube.com/watch?v=MFphfVq5HoY'),(3,'창의적인 아이는 저절로 길러지지 않습니다. 어떻게 하면 아이를 창의적으로 기를 수 있을까요?','OPENNESS','https://img.youtube.com/vi/ktkTIQqKYu0/0.jpg','창의성이 그냥 생길리 있나요? 창의적인 아이로 키우는 부모는 이렇게 물어봅니다','https://www.youtube.com/watch?v=ktkTIQqKYu0'),(4,'부모가 \"이렇게\" 말하면, 아이의 창의력이 높아집니다','OPENNESS','https://img.youtube.com/vi/Vr8ezZutlaY/0.jpg','인문 교육 전문가 김종원의 아이의 삶을 바꾸는 대화법','https://www.youtube.com/watch?v=Vr8ezZutlaY'),(5,'아이를 창의적으로 키우고 싶다면 4가지 생활 태도에 집중!','OPENNESS','https://img.youtube.com/vi/YleuGhRClg0/0.jpg','창의성을 키우는 4가지 생활 태도','https://www.youtube.com/watch?v=YleuGhRClg0'),(6,'창의적인 아이로 키우는 쉬운 방법','OPENNESS','https://img.youtube.com/vi/JKEorn4fM_0/0.jpg','창의성을 잃지 않는 환경 조성','https://www.youtube.com/watch?v=JKEorn4fM_0'),(7,'아이의 자존감을 높여주는 부모의 행동수칙','EXTRAVERSION','https://img.youtube.com/vi/n2ZVyWjJSNA/0.jpg','육아전문가 오은영 박사의 자존감 강의','https://www.youtube.com/watch?v=n2ZVyWjJSNA'),(8,'내 아이를 건드리거나 약올리는 친구가 있을 때 | 오은영 박사의 해결법','EXTRAVERSION','https://img.youtube.com/vi/rYqjTcT8VpU/0.jpg','또래 친구와의 갈등 해결법','https://www.youtube.com/watch?v=rYqjTcT8VpU'),(9,'느리고 수줍음 많은 아이가 못마땅한 부모','EXTRAVERSION','https://img.youtube.com/vi/U2rn73R69_s/0.jpg','부모가 할 수 있는 올바른 지원 방법','https://www.youtube.com/watch?v=U2rn73R69_s'),(10,'소극적인 아이의 학교생활 적응법','EXTRAVERSION','https://img.youtube.com/vi/cZjLzRMxY3U/0.jpg','소극적인 아이를 돕는 부모의 역할','https://www.youtube.com/watch?v=cZjLzRMxY3U'),(11,'수줍음이 많은 아이 양육법','EXTRAVERSION','https://img.youtube.com/vi/e5mpaTp643Y/0.jpg','수줍음 많은 아이를 도와주는 방법','https://www.youtube.com/watch?v=e5mpaTp643Y'),(12,'아이의 짜증이 부쩍 늘어났다면?♨ 짜증에 대처하는 올바른 방법!','EMOTIONAL_STABILITY','https://img.youtube.com/vi/2zjY22NqLOY/0.jpg','아이의 짜증을 다루는 방법','https://www.youtube.com/watch?v=2zjY22NqLOY'),(13,'[EBS부모] 아이의 스트레스 이렇게 해주세요','EMOTIONAL_STABILITY','https://img.youtube.com/vi/O4HOqe4TbCo/0.jpg','아이의 스트레스 관리법','https://www.youtube.com/watch?v=O4HOqe4TbCo'),(14,'불안한 아이들이 자주 하는 질문','EMOTIONAL_STABILITY','https://img.youtube.com/vi/ki4_re9KLVY/0.jpg','아이의 불안을 다루는 대화법','https://www.youtube.com/watch?v=ki4_re9KLVY'),(15,'[육아] 훈육으로 해결되지 않는 영유아기 스트레스','EMOTIONAL_STABILITY','https://img.youtube.com/vi/IMGhTDxOyrY/0.jpg','훈육과 스트레스의 관계','https://www.youtube.com/watch?v=IMGhTDxOyrY'),(16,'아이의 스트레스를 인정하고 가정 안에서 해결하기 위한 방법','EMOTIONAL_STABILITY','https://img.youtube.com/vi/18qQmaXqEpc/0.jpg','가정에서 아이의 스트레스를 다루는 법','https://www.youtube.com/watch?v=18qQmaXqEpc'),(17,'★최초공개★ 오은영 박사의 어떻게 놀아줘야할까_1탄','AGREEABLENESS','https://img.youtube.com/vi/o3GbpgZ-jMs/0.jpg','아이와 놀이를 효과적으로 하는 방법','https://www.youtube.com/watch?v=o3GbpgZ-jMs'),(18,'아이와 ⭐️놀이터에 갔을때 ⭐️오은영 박사가 알려주는 꿀팁!','AGREEABLENESS','https://img.youtube.com/vi/flULwJu6TDE/0.jpg','놀이터에서 아이와 효과적으로 놀아주는 법','https://www.youtube.com/watch?v=flULwJu6TDE'),(19,'예의 바른 아이로 키우고 싶다면? 먼저 아이의 마음을 읽어주세요!','AGREEABLENESS','https://img.youtube.com/vi/HqyV1uPWrfY/0.jpg','아이에게 올바른 예의를 가르치는 법','https://www.youtube.com/watch?v=HqyV1uPWrfY'),(20,'성격 급한 아이, 규칙을 잘 못 지키는 아이 어떻게 가르쳐야 할까요?','AGREEABLENESS','https://img.youtube.com/vi/uLPsZNk12UM/0.jpg','아이의 성격을 존중하며 지도하는 법','https://www.youtube.com/watch?v=uLPsZNk12UM'),(21,'아이의 짜증이 부쩍 늘어났다면?♨ 짜증에 대처하는 올바른 방법!','AGREEABLENESS','https://img.youtube.com/vi/2zjY22NqLOY/0.jpg','아이의 감정을 이해하고 조절하는 법','https://www.youtube.com/watch?v=2zjY22NqLOY'),(22,'돼지우리가 따로 없는 아들의 방, 정리정돈을 잘하게 하는 방법','CONSCIENTIOUSNESS','https://img.youtube.com/vi/IerB-iV1kpU/0.jpg','아이의 정리정돈 습관 만들기','https://www.youtube.com/watch?v=IerB-iV1kpU'),(23,'절대 게으른 탓이 아니다! 침대·바닥·심지어 책상 밑, 계속 누워만 있었던 이유','CONSCIENTIOUSNESS','https://img.youtube.com/vi/wFjUOyHnQ5Y/0.jpg','아이의 행동을 이해하고 돕는 방법','https://www.youtube.com/watch?v=wFjUOyHnQ5Y'),(24,'지저분하고 정리 못하는 중1 아이, 어떻게 지도해야 할까요?','CONSCIENTIOUSNESS','https://img.youtube.com/vi/BpMxrmT_NUA/0.jpg','아이의 정리정돈 습관 지도법','https://www.youtube.com/watch?v=BpMxrmT_NUA'),(25,'유치원에서 정리정돈 잘 하는 아이, 집에서는 왜 안 할까요?','CONSCIENTIOUSNESS','https://img.youtube.com/vi/4dxq-dMek9s/0.jpg','아이의 생활 습관 일관되게 유지하기','https://www.youtube.com/watch?v=4dxq-dMek9s'),(26,'정리정돈을 잘하는 아이로 키우는 방법','CONSCIENTIOUSNESS','https://img.youtube.com/vi/_W_l_PGFBY0/0.jpg','정리 습관을 키우는 부모의 역할','https://www.youtube.com/watch?v=_W_l_PGFBY0');
/*!40000 ALTER TABLE `education` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  8:55:09
