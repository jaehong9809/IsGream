-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: iscream
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pat_test`
--

DROP TABLE IF EXISTS `pat_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pat_test` (
  `pat_test_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `test_date` date NOT NULL,
  `a_score` int NOT NULL,
  `b_score` int NOT NULL,
  `c_score` int NOT NULL,
  `result` enum('A','B','C') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdf_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`pat_test_id`),
  KEY `pat_test_ibfk_1` (`user_id`),
  CONSTRAINT `pat_test_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pat_test`
--

LOCK TABLES `pat_test` WRITE;
/*!40000 ALTER TABLE `pat_test` DISABLE KEYS */;
INSERT INTO `pat_test` VALUES (1,1,'2025-02-17',0,0,0,'A',NULL),(2,1,'2025-02-17',0,0,0,'A',NULL),(3,1,'2025-02-17',5,3,8,'C','https://a407-20250124.s3.ap-northeast-2.amazonaws.com/result/8b092f61-6c72-4de7-a39b-c90b219ee884_1739759273459.pdf'),(4,3,'2025-02-17',0,0,0,'A',NULL),(5,1,'2025-02-17',8,6,5,'A',NULL),(6,1,'2025-02-17',8,6,4,'A',NULL),(7,3,'2025-02-17',6,5,8,'C',NULL),(8,1,'2025-02-17',0,1,18,'C',NULL),(9,1,'2025-02-17',1,4,14,'C',NULL),(10,1,'2025-02-17',3,4,12,'C',NULL),(11,1,'2025-02-17',0,4,15,'C',NULL),(12,1,'2025-02-17',1,2,16,'C',NULL),(13,1,'2025-02-17',1,8,10,'C',NULL),(14,1,'2025-02-17',1,8,10,'C',NULL),(15,1,'2025-02-17',1,5,13,'C',NULL),(16,7,'2025-02-17',7,4,8,'C','https://a407-20250124.s3.ap-northeast-2.amazonaws.com/result/7b610b18-0e6b-48c0-a907-bd94f9165367_1739820611283.pdf'),(17,7,'2025-02-17',1,1,17,'C',NULL),(18,7,'2025-02-17',0,19,0,'B',NULL),(19,7,'2025-02-17',7,5,7,'A',NULL),(20,7,'2025-02-17',10,9,0,'A',NULL),(21,7,'2025-02-17',10,6,3,'A',NULL),(22,7,'2025-02-17',15,4,0,'A',NULL),(23,7,'2025-02-17',5,3,8,'C',NULL),(24,7,'2025-02-17',7,7,5,'A',NULL),(25,7,'2025-02-17',5,3,8,'C',NULL),(26,7,'2025-02-17',5,3,8,'C',NULL),(27,7,'2025-02-17',5,3,8,'C',NULL),(28,7,'2025-02-17',5,3,8,'C',NULL),(29,7,'2025-02-17',5,3,8,'C',NULL),(30,7,'2025-02-17',5,3,8,'C',NULL),(31,7,'2025-02-17',7,7,5,'A',NULL),(32,7,'2025-02-17',7,7,5,'A',NULL),(33,7,'2025-02-17',0,5,14,'C',NULL),(34,7,'2025-02-17',8,6,5,'A',NULL),(35,7,'2025-02-17',9,5,5,'A',NULL),(36,7,'2025-02-17',9,5,5,'A',NULL),(37,7,'2025-02-17',4,10,5,'B',NULL),(38,7,'2025-02-17',19,0,0,'A',NULL),(39,7,'2025-02-17',15,4,0,'A',NULL),(40,1,'2025-02-18',7,8,9,'C',NULL),(41,1,'2025-02-18',14,4,1,'A',NULL),(42,1,'2025-02-18',1,2,0,'B',NULL),(43,1,'2025-02-18',10,6,3,'A',NULL),(44,1,'2025-02-18',6,5,8,'C',NULL),(45,1,'2025-02-18',1,1,0,'A',NULL),(46,1,'2025-02-18',2,8,9,'C',NULL),(47,1,'2025-02-18',0,2,0,'B',NULL),(48,1,'2025-02-18',7,4,8,'C',NULL),(49,1,'2025-02-18',5,8,6,'B',NULL),(50,1,'2025-02-18',3,9,7,'B',NULL),(51,1,'2025-02-18',4,9,6,'B',NULL),(52,1,'2025-02-18',6,7,6,'B',NULL),(53,3,'2025-02-19',5,3,11,'C',NULL),(54,8,'2025-02-19',6,2,11,'C',NULL),(55,3,'2025-02-19',0,1,18,'C',NULL),(56,3,'2025-02-19',0,1,18,'C',NULL),(57,1,'2025-02-19',4,7,8,'C',NULL),(58,13,'2025-02-19',7,7,5,'A','https://a407-20250124.s3.ap-northeast-2.amazonaws.com/result/886a689a-9424-4dc0-87c0-0fe4585f39b4_1740048924352.pdf'),(59,5,'2025-02-20',2,2,15,'C',NULL),(60,16,'2025-02-20',5,8,6,'B',NULL),(61,16,'2025-02-20',7,4,8,'C',NULL),(62,2,'2025-02-20',0,2,17,'C','https://a407-20250124.s3.ap-northeast-2.amazonaws.com/result/3a397c5b-1b83-4ea6-80d8-4ac81da92e41_1740043249975.pdf'),(63,7,'2025-02-20',6,3,10,'C',NULL),(64,18,'2025-02-20',3,9,7,'B',NULL),(65,1,'2025-02-20',2,6,11,'C',NULL),(66,1,'2025-02-20',2,6,11,'C',NULL),(67,21,'2025-02-20',0,0,19,'C',NULL),(68,2,'2025-02-20',1,0,18,'C',NULL),(69,2,'2025-02-20',1,0,18,'C',NULL),(70,1,'2025-02-21',5,1,13,'C',NULL);
/*!40000 ALTER TABLE `pat_test` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  8:54:50
