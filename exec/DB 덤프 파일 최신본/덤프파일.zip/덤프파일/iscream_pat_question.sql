-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: iscream
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pat_question`
--

DROP TABLE IF EXISTS `pat_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pat_question` (
  `question_id` int NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '아이의 짜증을 멈추게 하기 위해 옆에서 도와준다',
  `answer2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pat_question`
--

LOCK TABLES `pat_question` WRITE;
/*!40000 ALTER TABLE `pat_question` DISABLE KEYS */;
INSERT INTO `pat_question` VALUES (1,'식사시간이 얼마 남지 않았는데도 당신의 아이가 군것질을 먹겠다고 조르자 시어머님(장모님)께서 먹으라고 허락한다면?','그대로 먹게 내버려 둔다.','안 된다고 하며 못 먹게 한다.','밥을 먹고 난 다음에 후식으로만 먹게 한다.'),(2,'당신의 6살 난 아이가 청소년들이 볼 수 있는 만화영화를 보겠다고 때를 쓴다면?','보도록 내버려 둔다.','보지 못하게 TV를 끄거나 채널을 다른 프로그램으로 돌린다.','아이에게 적합한지를 직접 시청한 다음 보게 할 것인지를 결정한다.'),(3,'당신의 아이가 반찬고리(바느질고리)를 뒤집어엎어 온 방안에 해처 놓았다면?','아이이니까 그러려니 하고 손수 치운다.','화를 내며 지금 당장 치우라고 소리친다. (당장 치워!!!)','화를 내지는 않지만 아이에게 치우게 하고, 다 치울 때 까지 다른 일을 못하게 한다.'),(4,'아이가 당신이 아끼던 꽃병을 깨뜨리고선 옆집 친구가 그랬다고 거짓말을 했다면?','아깝지만 괜찮다고 이야기 한다.','깨뜨린 것과 거짓말 한 것 모두에 대해 야단을 치거나 벌을 준다.','거짓말 한 것에 대해 야단을 치고, 만일 솔직히 얘기했더라면 꽃병을 깬 것에 대해 혼내지 않았을 것이라고 말해준다.'),(5,'7살짜리 당신의 아이가 서너 살짜리 아이들과 노는 것을 보았다면?','속은 상하지만 그냥 놀게 내버려 둔다.','당장 놀지 못하게 한다.','같이 놀 또래 친구들을 찾아보도록 도와준다.'),(6,'당신의 아이가 다른 친구를 때려서 상처를 냈다면?','아이들 싸움이려니 하고 그냥 내버려 둔다.','핀가 나서 야단치거나 때론 체벌을 한다.','왜 싸웠는지에 대해 이야기를 나누되, 그래도 싸움은 나쁘다고 따끔히 꾸중한다.'),(7,'당신의 아이가 유치원(학교)에서 내준 숙제를 이번에도 또 잊고 안 해간다면?','선생님께 전화를 해준다.','그 자리에서 혼을 내고 다시는 그러지 못하도록 다짐해 둔다.','더 이상 잊어버리지 않도록 타이르고 다음부터는 일련장을 꼭 확인하도록 도와준다.'),(8,'당신의 아이가 크레용으로 온 방바닥에 낙서를 했다면?','낙서할 수 있는 종이를 한 묶음 갖다 주며 웃어넘긴다.','아이에게 화를 내며 당신이 직접 낙서를 지운 다음, 크레용을 모두 없애 버린다.','아이 스스로 지우게 하고, 다음부터는 크레용을 가지고 놀 때 세심히 지도한다.'),(9,'당신의 아이가 유치원(학교)에서 친구를 사귀는데 문제가 있다면?','친구들을 불러서 파티를 열어주고 선물을 나누어주며 당신의 아이와 사이좋게 지내달라고 부탁한다.','바보처럼 친구 하나도 못 사귄다고 야단을 친다.','당신의 자녀와 친구관계에 관한 이야기를 나누고, 친구를 사귈 수 있도록 단체 활동 프로그램 등에 가입시킨다.'),(10,'당신의 기분이 언짢은데 자녀가 당신의 관심을 받고자 보챈다면?','언짢은 기분은 되로 하고 자녀에게 관심을 기울인다.','아이에게 짜증내며 남편(아내)을 불러 떠넘긴다. \"네 아빠(엄마)한테나 가봐!\"','아이에게 당신의 기분이 언짢다는 것을 이야기 해주고, 좀 나아지면 함께 놀아주겠다고 한다.'),(11,'당신의 아이가 블록 쌓기 놀이를 하는데 원하는 대로 잘 되지 않아서 짜증을 부린다면?','아이의 짜증을 멈추게 하기 위해 옆에서 도와준다','짜증부리지 말라고 야단을 친다.','아이에게 짜증을 부리는 대신 말로 표현하도록 얘기해 주고 짜증난 이유에 대해 이야기를 나눈다.'),(12,'당신의 집에는 자녀가 지켜야 할 규칙이 얼마나 많습니까?','없다.','많은 규칙이 있고, 규칙마다 이를 어겼을 시 받게 될 규중이나 벌이 정해져 있다.','아이의 건강과 안전을 위한 몇 가지의 규칙이 있긴 하나, 그때마다 상황에 따라 그 때 그 때 대화를 통해 결정한다.'),(13,'당신이 좋아하는 수제비를 특별히 준비하였는데 아이가 먹기 싫다고 한다면?','귀찮더라도 아이를 위해 밥을 따로 준비한다.','억지로라도 먹게 한다.','수제비를 조금이라도 먹어보게 한 다음 그래도 싫다면 아이를 위해 밥을 따로 준비한다.'),(14,'자야 할 시간이 훨씬 지났는데도 아이가 하고 있던 놀이를 더 하고 자겠다고 고집을 피운다면?','놀만큼 더 놀다 자게 한다.','당장 가서 자라며 야단치거나 불을 꺼버린다.','그 시각부터 20~30분만 더 놀다 자게 한다.'),(15,'당신의 아이가 다른 어른의 말을 잘 따르지 않는다면?','아직 어리니까 그러려니 하고 내버려둔다.','화를 내며 어쨌든 어른의 말을 따르지 않는다는 건 나쁜 일이기에 야단친다.','어른에 대한 공경심과 그 어른의 말을 왜 따라야 하는지에 대해 이야기를 나눈다.'),(16,'아이와 함께 쇼핑 시, 쓸모없어 보이는 것들을 이것저것 사달라고 조른 다면?','가능한 다 들어준다.','화를 내면서 아이의 손목을 잡고 그 상점을 뜬다.','안 된다고 딱 잘라 말하고, 쇼핑을 계속하면서 아이에게 적합한 것을 골라 사준다.'),(17,'당신은 얼마나 자주 자녀에게 화를 냅니까?','거의 드물다.','매일 같이','일주일에 한번 정도'),(18,'당신의 아이가 자다가 무서운 꿈을 꾸어 당신의 방에서 자겠다고 오는 경우','함께 자도록 한다.','당장 네 방에 가서 자라고 소리 지른다.','일어나서 아이를 달래준 다음 아이들 방으로 데려가 재운다.'),(19,'당신의 아이를 생각할 때, 당신이 원하는 가정의 분위기는?','자유롭고 개방적인 가정','규율과 질서가 잡힌 가정','대화와 화합이 있는 가정');
/*!40000 ALTER TABLE `pat_question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  8:55:28
